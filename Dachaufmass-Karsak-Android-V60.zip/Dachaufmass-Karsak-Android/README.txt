Dachaufmaß Karsak – Android-Projekt
Version: V60

Die funktionierende V60 index.html wurde unverändert in app/src/main/assets übernommen.

APK in Android Studio:
1. ZIP entpacken.
2. Ordner Dachaufmass-Karsak-Android in Android Studio öffnen.
3. Gradle-Synchronisierung abwarten.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK liegt danach unter app/build/outputs/apk/debug/app-debug.apk.

App-Name: Dachaufmaß Karsak
Paket: de.karsak.dachaufmass
