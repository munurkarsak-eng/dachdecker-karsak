Dachaufmaß Karsak – App V57

Dateien:
- index.html
- manifest.webmanifest
- sw.js
- icons/

Für GitHub Pages:
1. Den Inhalt dieses Ordners in das bestehende GitHub-Pages-Repository hochladen.
2. Die bisherige HTML-Startdatei durch index.html ersetzen.
3. Seite auf dem Android-Handy öffnen.
4. Auf „App auf diesem Gerät installieren“ tippen oder im Browser „App installieren“ wählen.

Die App läuft danach im Standalone-Modus und cached die Oberfläche für Offline-Start.
Gespeicherte Projekte bleiben wie bisher im lokalen Browser-/App-Speicher des Geräts.
